#ifndef PIN_DEFINES_H
#define PIN_DEFINES_H

#define door_sensor     A0
#define speed_pot       A1
#define left_indicator  2
#define right_indicator 3
#define thermo_SO       4
#define thermo_CS       5
#define thermo_SCK      6

#define CAN2515_CS      10

#endif