import os
import sys

from PyQt5.QtWidgets import *
from PyQt5.QtGui import QIcon, QFont, QFontDatabase
from PyQt5.QtCore import *
from serialThreadFile import serialThreadClass

################################################################################################
# Convert UI to PyQt5 py file
################################################################################################
#os.system("pyuic5 -o interface_ui.py interface.ui")

################################################################################################
# Import the generated UI File
################################################################################################
from interface_ui import *

##################################################################################################
# MAIN WINDOW CLASS
################################################################################################
class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self)
        
        # Set the window flags to remove window title bar and maximize button
        self.setWindowFlags(self.windowFlags() | QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint)

        # Set the fixed window size to match the resolution of the HDMI display
        self.setFixedSize(1024, 600)  # Replace with the resolution of your HDMI display
        
        ################################################################################################
        # Setup the UI main window
        ################################################################################################
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # Set the window title
        self.setWindowTitle("Pi Cluster")
                
        ################################################################################################
        # Creating two QTimers for flashing left and right indicators
        ################################################################################################
        self.timerR = QTimer()
        self.timerL = QTimer()
        
        # Connect the timer timeout signals to their respective methods
        self.timerR.timeout.connect(self.timer_timeoutR)
        self.timerL.timeout.connect(self.timer_timeoutL)

        # Create a QTimer for blinking the critical warning message box
        self.temp_msgtimer = QTimer()
        self.temp_msgtimer.timeout.connect(self.toggle_message_box_visibility)
        
        self.mySerial = serialThreadClass()
        self.mySerial.data_ready.connect(self.handle_data_ready)  # Connect the data_ready signal to a slot
        self.mySerial.start() #run thread for receiving 

        self.isFlashingIndR = False
        self.isFlashingIndL = False
        self.handle_data_processing = False
        
        ################################################################################################
        # Show window
        ################################################################################################
        self.show()
        # Specify the temperature threshold
        self.temperature_threshold = 50

        self.ui.gauge.setGaugeTheme(24)
        
        ################################################################################################
        # DEFAULT MINIMUM AND MAXIMUM VALUE
        ################################################################################################
        self.ui.gauge.minValue = 0
        self.ui.gauge.maxValue = 300
        ################################################################################################
        # SET GAUGE UNITS
        ################################################################################################
        self.ui.gauge.units = "Km/h" #gauge unit as Km/h, Mph etc (shown as text on the gauge)

        ################################################################################################
        # SET SCALE POLYGON COLOR (PASS ONE COLOR OR 3 COLORS FOR GRADIENT)
        ################################################################################################
        self.ui.gauge.setScalePolygonColor(
            color1 = "#FF0022", #red
            color2 = "#025752", #middle-green
            color3 = "#023b37", #start-dark-green
               
        )

        #################################################################################################################
        # SET NEEDLE COLOR (PASSING RGB VALUE WITH TRANSPARENCY-0-255)
        #################################################################################################################
        self.ui.gauge.setNeedleColor(255, 0, 0, 255) #red

        ################################################################################################
        # ENABLE NEEDLE MOUSE TRACKING BY DEFAULT
        ################################################################################################
        self.ui.gauge.setMouseTracking(False)

    def showEvent(self, event):
        # Maximize the window to take up the full screen space
        self.showMaximized()
        super().showEvent(event)

    def start_timer(self, timer):
        print("Starting Timer")
        if not timer.isActive():
            timer.start(1000)  # Start the timer with a timeout of 1000ms (1 second)
        
    def stop_timer(self, timer, timer_id):
        print(f"Stopping Timer {timer_id}")
        if timer.isActive():
            timer.stop()
            
        if timer_id == "R":
            self.ui.pushbtnR.setStyleSheet('background-color: white; border-style: solid; border-width:1px; border-radius:50px; border-color: red; max-width:100px; max-height:100px; min-width:100px; min-height:100px;')
        else:
            self.ui.pushbtnL.setStyleSheet('background-color: white; border-style: solid; border-width:1px; border-radius:50px; border-color: red; max-width:100px; max-height:100px; min-width:100px; min-height:100px;')            

    def handle_data_ready(self, ard_read):
        if self.handle_data_processing:
            return
        self.handle_data_processing = True
        
        data_array = ard_read.split(', ')
        if len(data_array) >= 5:
            right_ind, left_ind, door_state, speed, temp_val = data_array[:5]
            #Setting Temperature value on GUI
            self.ui.lcdNumber.display(temp_val)

            # Check if temperature exceeds the threshold
            if int(temp_val) > self.temperature_threshold and not self.temp_msgtimer.isActive():
                # Display a critical temperature warning
                self.show_critical_temperature_warning()
            elif int(temp_val) < self.temperature_threshold and self.temp_msgtimer.isActive():
                # Temperature is below the threshold, cancel the message box if it's visible
                if self.msg_box.isVisible():
                    self.cancel_critical_temperature_warning()
                    
            #Setting Analog Gauge Speed needle value
            self.ui.gauge.updateValue(int(speed))            
            if door_state == '1':
                self.ui.pushDoor.setStyleSheet("QPushButton{\n"
                    "    background-color: red;\n"
                    "    border-width: 2px;\n"
                    "    border-color: black;\n"
                    "    border-radius: 8px;\n"
                    "    max-height: 60px;\n"
                    "    text-align: center;\n"
                    "    \n"
                "}")
                
                self.ui.pushDoor.setText("Door is Unlocked")
            else:
                self.ui.pushDoor.setStyleSheet("QPushButton{\n"
                    "    background-color: #32e638;\n"
                    "    border-width: 2px;\n"
                    "    border-color: black;\n"
                    "    border-radius: 8px;\n"
                    "    max-height: 60px;\n"
                    "    text-align: center;\n"
                    "    \n"
                "}")
                
                self.ui.pushDoor.setText("Door is Locked")
                
            if right_ind == '1' and not self.timerR.isActive():
                print("Right Indicator ON")
                self.start_timer(self.timerR)  # Start the delay timer
            elif right_ind == '0' and self.timerR.isActive():
                print("Right Indicator OFF")
                self.stop_timer(self.timerR, "R")

            if left_ind == '1' and not self.timerL.isActive():
                print("Left Indicator ON")
                self.start_timer(self.timerL)  # Start the delay timer
            elif left_ind == '0' and self.timerL.isActive():
                print("Left Indicator OFF")
                self.stop_timer(self.timerL, "L")

        self.handle_data_processing = False
    
    def timer_timeoutR(self):
        print("TimerR timeout")
        if self.isFlashingIndR:
            self.ui.pushbtnR.setStyleSheet('background-color: #32e638; border-style: solid; border-width:1px; border-radius:50px; border-color: red; max-width:100px; max-height:100px; min-width:100px; min-height:100px;')
        else:
            self.ui.pushbtnR.setStyleSheet('background-color: white; border-style: solid; border-width:1px; border-radius:50px; border-color: red; max-width:100px; max-height:100px; min-width:100px; min-height:100px;')
        
        self.isFlashingIndR = not self.isFlashingIndR

    def timer_timeoutL(self):
        print("TimerL timeout")
        if self.isFlashingIndL:
            self.ui.pushbtnL.setStyleSheet('background-color: #32e638; border-style: solid; border-width:1px; border-radius:50px; border-color: red; max-width:100px; max-height:100px; min-width:100px; min-height:100px;')
        else:
            self.ui.pushbtnL.setStyleSheet('background-color: white; border-style: solid; border-width:1px; border-radius:50px; border-color: red; max-width:100px; max-height:100px; min-width:100px; min-height:100px;')
        
        self.isFlashingIndL = not self.isFlashingIndL

    def show_critical_temperature_warning(self):
        # Create a QMessageBox with critical icon and appropriate text
        self.msg_box = QMessageBox(self)
        self.msg_box.setIcon(QMessageBox.Critical)
        self.msg_box.setWindowTitle("Critical Temperature!!")
        self.msg_box.setText("Temperature exceeds above 50°C !!!")
        self.msg_box.setWindowFlags(self.msg_box.windowFlags() | Qt.WindowStaysOnTopHint)
        self.msg_box.setStandardButtons(QMessageBox.NoButton)

        # Start the blinking timer
        self.temp_msgtimer.start(500)  # Blink every 500ms (0.5 seconds)
        
        # Display the QMessageBox
        self.msg_box.show()

    def toggle_message_box_visibility(self):
        if self.msg_box.isVisible():
            self.msg_box.hide()
        else:
            self.msg_box.show()

    def cancel_critical_temperature_warning(self):
        # Stop the blinking timer
        self.temp_msgtimer.stop()
        
        # Hide the QMessageBox
        self.msg_box.hide()

########################################################################
## EXECUTE APP
########################################################################
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ########################################################################
    ## 
    ########################################################################
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

########################################################################
## END===>
########################################################################
