import serial
from PyQt5.QtCore import pyqtSignal, QThread

class serialThreadClass(QThread):
    data_ready = pyqtSignal(str)

    def __init__(self, parent=None):
        super(serialThreadClass, self).__init__(parent)
        self.serialPort = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)
        #self.data_array = None
        #self.data_queue = Queue()
        #self.data_initialized = False
        
    def run(self): #Thread run function
        while True:
            ard_read = self.serialPort.readline().decode('utf-8').rstrip()
            #self.data_array = ard_read.split(', ')  # Split the line using comma as the delimiter
            #self.data_queue.put(data_array)  # Put the data_array into the queue
            #self.data_initialized = True
            self.data_ready.emit(ard_read) #Emit the data_rady Signal
            #print(ard_read)
            #self.pyqt_temp.emit(str(data_array[4]))
            #print(data_array[len(self.data_array)-1])

    '''def read_data(self, value):
        if self.data_initialized and self.data_array is not None and 0 <= value < len(self.data_array):
            return self.data_array[value]
        return None'''
