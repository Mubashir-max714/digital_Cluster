import os
import sys

from PyQt5.QtWidgets import *
from PyQt5.QtGui import QIcon, QFont, QFontDatabase
from PyQt5.QtCore import *
from serialThreadFile import serialThreadClass
################################################################################################
# Convert UI to PyQt5 py file
################################################################################################
#os.system("pyuic5 -o interface_ui.py interface.ui")
# os.system("pyuic5 -o analoggaugewidget_demo_ui.py analoggaugewidget_demo.ui.oQCkCR")

################################################################################################
# Import the generated UI File
################################################################################################
from interface_ui import *

##################################################################################################
# MAIN WINDOW CLASS
################################################################################################
class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self)
        ################################################################################################
        # Setup the UI main window
        ################################################################################################
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        
        self.timerR = QTimer()
        
        # Connect timeout signals to respective timeout methods
        self.timerR.timeout.connect(self.timer_timeoutR)
        
        # Connect data_ready signal to handle_data_ready method
        self.mySerial = serialThreadClass()
        self.mySerial.data_ready.connect(self.handle_data_ready)
        self.mySerial.start()
        
        self.handle_data_processing = False
        self.isFlashingIndR = False
        
        ################################################################################################
        # Show window
        ################################################################################################
        self.show()
        
        self.ui.lcdNumber.display(36)
        self.ui.gauge.setGaugeTheme(24)

        self.ui.gauge.minValue = 0
        self.ui.gauge.maxValue = 300

        self.ui.gauge.units = "Km/h" #gauge unit as Km/h, Mph etc (shown as text on the gauge)

        self.ui.gauge.setScalePolygonColor(
            color1 = "#FF0022", #red
            color2 = "#025752", #middle-green
            color3 = "#023b37", #start-dark-green
               
        )

        self.ui.gauge.setNeedleColor(255, 0, 0, 255) #red

        self.ui.gauge.setMouseTracking(False)

        
    def start_timer(self, timer):
        print("Starting Timer")
        if not timer.isActive():
            timer.start(1000)  # Start the timer with a timeout of 1000ms (1 second)
        
    def stop_timer(self, timer):
        print("Stopping Timer")
        if timer.isActive():
            timer.stop()
        self.ui.pushbtnR.setStyleSheet('background-color: white; border-style: solid; border-width:1px; border-radius:50px; border-color: red; max-width:100px; max-height:100px; min-width:100px; min-height:100px;')
        
            
            
    def handle_data_ready(self, ard_read):
        if self.handle_data_processing:
            return
        self.handle_data_processing = True
        
        data_array = ard_read.split(', ')
        if len(data_array) >= 5:
            right_ind, left_ind, door_state, speed, temp_val = data_array[:5]
            self.ui.lcdNumber.display(temp_val)
            
            if right_ind == '1' and not self.timerR.isActive():
                print("Im here")
                self.start_timer(self.timerR)  # Start the delay timer
            elif right_ind == '0' and self.timerR.isActive():
                print("sorry")
                self.stop_timer(self.timerR)
        
        self.handle_data_processing = False
    
    def timer_timeoutR(self):
        print("Timer timeout 1!")
        if self.isFlashingIndR:
            self.ui.pushbtnR.setStyleSheet('background-color: #32e638; border-style: solid; border-width:1px; border-radius:50px; border-color: red; max-width:100px; max-height:100px; min-width:100px; min-height:100px;')
        else:
            self.ui.pushbtnR.setStyleSheet('background-color: white; border-style: solid; border-width:1px; border-radius:50px; border-color: red; max-width:100px; max-height:100px; min-width:100px; min-height:100px;')
        
        self.isFlashingIndR = not self.isFlashingIndR
        
    def checked(self):
        print("Hello!")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
